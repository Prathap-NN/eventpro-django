from django.db import models

# Create your models here.
from django.db.models.signals import pre_save
from events import settings
import os
from django.template.defaultfilters import slugify
from django_cryptography.fields import encrypt


class Images(models.Model):
    name = models.CharField(max_length=30)
    image = models.ImageField(upload_to="images",null=True,blank=True)

    def __str__(self):
        return self.name