from dataclasses import field
from django import forms

from ujwal_app import models


class Note(forms.ModelForm):
    title= forms.CharField(max_length=30)
    images = forms.FileField(widget=forms.ClearableFileInput(attrs={'multiple': True}),required=False)

    class Meta():
        model =models.Images
        fields = "__all__"