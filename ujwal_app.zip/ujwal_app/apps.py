from django.apps import AppConfig


class UjwalAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ujwal_app'
