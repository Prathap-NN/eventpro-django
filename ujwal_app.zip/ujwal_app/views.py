from unicodedata import name
from django.shortcuts import render

# Create your views here.
from django.shortcuts import render

from django.http import HttpResponseRedirect, JsonResponse
from django.urls import reverse_lazy
import datetime
from django.db.models import Q
from django.views.generic import ListView
from django.utils.translation import gettext_lazy as _
from .models import Images

def upload_image(request):
    if request.method == "POST":
        files = request.FILES.getlist('images')
        name = request.POST.get('name')
        for f in files:
            Images.objects.create(name=name,image=f)
        images = Images.objects.all()
        context = {'images': images}
        return render(request, 'ujwal_app/upload.html',context)
    else:
        images = Images.objects.all()
        context = {'images': images}
        return render(request, 'ujwal_app/upload.html',context)
    
    
